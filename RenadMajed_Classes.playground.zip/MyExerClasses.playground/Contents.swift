import UIKit

class University{
    static var name: String = ""
    var universityName: String = ""
    fileprivate var collegeName: String = ""
    public var descriptionuni: String{
        return "Hello \(University.name), you're at \(universityName) University. We appreciate your choosing \(universityName) University, and we hope to get a fun experience inside the university." }
    
    func descriptioncoll() {
        print(collegeName)
    }
//    var descriptioncoll: String{
//        return "You choose the \(University.collegeName) college, We appreciate to choosing this college 🚀✨.." }
//
    init(name: String = "", universityName: String = "", collegeName: String = ""){
        University.name = name
        self.universityName = universityName
        self.collegeName = collegeName
    } }

// 1. PNU University

class PNU: University{

    func uni() {
        print(descriptionuni)
    } }

class PNUCollege: PNU{
    var pnucollege: String = ""
    var pnumajor: String = ""
    var pnugpa: Double = 0
    
    init(pnucollege: String = "", pnumajor: String = "", pnugpa: Double = 0) {
        self.pnucollege = pnucollege
        self.pnumajor = pnumajor
        self.pnugpa = pnugpa
    }
    
    override func descriptioncoll() {
        print("You choose the \(pnucollege) college, the major you choose it is \(pnumajor) from \(pnucollege), and the GPA required is \(pnugpa)")
    }
}

class PNULibrary: PNU{
    var fullname: String = ""
    private var id: Int = 0
    var age: Int = 0
    var gender: Bool = true
    
    init(fullname: String = "", id: Int = 0, age: Int = 0, gender: Bool = true){
        self.fullname = fullname
        self.id = id
        self.age = age
        self.gender = gender
    }
    func brief() {
        print("Hello, you are in the PNU library. You should write your full name and your ID, also you should write your gender because the library is open from Saturday until Thursday just for Female")
    }
    func condition() {
        age = 24
        gender = true
        if age >= 18 && gender == true{
            print("Hello, you are in PNU library. please write your full name: \(fullname), and your is ID: \(id), also are you female? \(gender)")
        } else {
            print("Sorry you don't have access to enter, because your a Male or your age less than 18")
        }
    } }
class PNUHospital: PNU{
    var passionname: String = ""
    private var id: Int = 0
    
    init(passionname: String = "", id: Int = 0){
        self.passionname = passionname
        self.id = id
    }
    func bill1(x: Float, scout: Float)-> Float {
       while x >= 50 {
            print("Hi \(passionname), you have discount for a  student of 50%, the price of scout is:", (x / scout) * 100)
            break
        }
        return (x / scout) * 100
    }
 }
class PNUGym: PNU{
    var braceletnum: Int = 0
    var gymequipment: Bool = true
    var age: Int = 0
    var goalsteeps: Int = 0
    
    init(braceletnum: Int = 0, gymequipment: Bool = true, age: Int = 0, goalsteeps: Int = 0) {
        self.braceletnum = braceletnum
        self.gymequipment = gymequipment
        self.age = age
        self.goalsteeps = goalsteeps
    }
    func gyme(x: Int, y: Int) {
        if x >= 18 || y >= 10000 {
            print("You're owner of the bracelet number \(braceletnum), welcome in our GYM. We hope to get a nice experience 🚀✨..")
            print("You're grate 🦾🤩, your goal of steeps today is: \(goalsteeps)")
        } else {
            print("Sorry, your age less than 18")
        }
    }}
class PNUStudentHousing: PNU{
    var firstname: String = ""
    var lastname: String = ""
    var arr1: [String] = ["Tabuk", "Abha", "Jeddah"]

    init(firstname: String = "", lastname: String = ""){
        self.firstname = firstname
        self.lastname = lastname
        
        
        for studenthouse in arr1 {
            switch studenthouse {
            case "Tabuk":
                print("I'm from Tabuk")
            case "Abha":
                print("I'm from Abha")
            case "Jeddah":
                print("I'm from Jeddah")
            default:
                print("Sorry, you don't have the authority")
            }
        }}
    func housing() {
//        for studenthouse in arr1 {
//            switch studenthouse {
//            case "Tabuk":
//                print("I'm from Tabuk")
//            case "Abha":
//                print("I'm from Abha")
//            case "Jeddah":
//                print("I'm from Jeddah")
//            default:
//                   print("Sorry, you don't have the authority")
//            }
//        }
        print("Hello in student house at PNU. Your full name please: \(firstname)"+" \(lastname). Where are you from? \(arr1[0])")

          }
    
}
// العمادة المركزية
class PNUDeanship: PNU{
    
}
// الحضانة
class PNUNursery: PNU{
    
}
// الملعب الرياضي
class PNUStadium: PNU{
    
}
class PNUStage: PNU{
    
}


// 2. PSU University

class PSU: University{
    
    func uni() {
        print(descriptionuni)
    } }

class PSUCollege: PSU{
    var psucollege: String = ""
    var psumajor: String = ""
    var psugpa: Float = 0
    
    init(psucollege: String = "", psumajor: String = "", psugpa: Float = 0) {
        self.psucollege = psucollege
        self.psumajor = psumajor
        self.psugpa = psugpa
    }
    
    override func descriptioncoll() {
        print("You choose the \(psucollege) college, the major you choose it is \(psumajor) from \(psucollege), and the GPA required is \(psugpa)")
    }
}

class PSULibrary: PSU{
    var fullname: String = ""
    private var id: Int = 0
    var age: Int = 0
    var gender: Bool = true
    
    init(fullname: String = "", id: Int = 0, age: Int = 0, gender: Bool = true){
        self.fullname = fullname
        self.id = id
        self.age = age
        self.gender = gender
    }
    func brief() {
        print("Hello, you are in the PSU library. You should write your full name and your ID, also you should write your gender because the library is open from Saturday until Thursday just for Female")
    }
    func condition() {
        age = 24
        gender = true
        if age >= 18 && gender == true{
            print("Hello, you are in PSU library. please write your full name: \(fullname), and your is ID: \(id), also are you female? \(gender)")
        } else {
            print("Sorry you don't have access to enter, because your a Male or your age less than 18")
        }
    } }
class PSUHospital: PSU{
    var passionname: String = ""
    private var id: Int = 0
    
    init(passionname: String = "", id: Int = 0){
        self.passionname = passionname
        self.id = id
    }
    func bill2(x: Float, scout: Float)-> Float {
       while x >= 50 {
            print("Hi \(passionname), you have discount for a  student of 65%, the price of scout is:", (x / scout) * 100)
            break
        }
        return (x / scout) * 100
    }
}
class PSUGym: PSU{
    var braceletnum: Int = 0
    var gymequipment: Bool = true
    var age: Int = 0
    var goalsteeps: Int = 0
    
    init(braceletnum: Int = 0, gymequipment: Bool = true, age: Int = 0, goalsteeps: Int = 0) {
        self.braceletnum = braceletnum
        self.gymequipment = gymequipment
        self.age = age
        self.goalsteeps = goalsteeps
    }
    func gyme(x: Int, y: Int) {
        if x >= 18 || y >= 10000 {
            print("You're owner of the bracelet number \(braceletnum), welcome in our GYM. We hope to get a nice experience 🚀✨..")
            print("You're grate 🦾🤩, your goal of steeps today is: \(goalsteeps)")
        } else {
            print("Sorry, your age less than 18")
        }
    }}

// الملعب الرياضي
class PSUStadium: PSU{
    
}
class PSUStage: PSU{
    
}

// 3. KSAU University

class KSAU: University{
    
    func uni() {
        print(descriptionuni)
    } }

class KSAUCollege: KSAU{
var ksaucollege: String = ""
var ksaumajor: String = ""
var ksaugpa: Float = 0

init(ksaucollege: String = "", ksaumajor: String = "", ksaugpa: Float = 0) {
    self.ksaucollege = ksaucollege
    self.ksaumajor = ksaumajor
    self.ksaugpa = ksaugpa
}

override func descriptioncoll() {
    print("You choose the \(ksaucollege) college, the major you choose it is \(ksaumajor) from \(ksaucollege), and the GPA required is \(ksaugpa)")
}
}

class KSAULibrary: KSAU{
var fullname: String = ""
private var id: Int = 0
var age: Int = 0
var gender: Bool = true

init(fullname: String = "", id: Int = 0, age: Int = 0, gender: Bool = true){
    self.fullname = fullname
    self.id = id
    self.age = age
    self.gender = gender
}
func brief() {
    print("Hello, you are in the KSAU library. You should write your full name and your ID, also you should write your gender because the library is open from Saturday until Thursday just for Female")
}
func condition() {
    age = 24
    gender = true
    if age >= 18 && gender == true{
        print("Hello, you are in PSU library. please write your full name: \(fullname), and your is ID: \(id), also are you female? \(gender)")
    } else {
        print("Sorry you don't have access to enter, because your a Male or your age less than 18")
    }
} }
class KSAUHospital: KSAU{
var passionname: String = ""
private var id: Int = 0

init(passionname: String = "", id: Int = 0){
    self.passionname = passionname
    self.id = id
}
func bill2(x: Float, scout: Float)-> Float {
   while x >= 50 {
        print("Hi \(passionname), you have discount for a  student of 60%, the price of scout is:", (x / scout) * 100)
        break
    }
    return (x / scout) * 100
}
}
class KSAUGym: KSAU{
var braceletnum: Int = 0
var gymequipment: Bool = true
var age: Int = 0
var goalsteeps: Int = 0

init(braceletnum: Int = 0, gymequipment: Bool = true, age: Int = 0, goalsteeps: Int = 0) {
    self.braceletnum = braceletnum
    self.gymequipment = gymequipment
    self.age = age
    self.goalsteeps = goalsteeps
}
func gyme(x: Int, y: Int) {
    if x >= 18 || y >= 15000 {
        print("You're owner of the bracelet number \(braceletnum), welcome in our GYM. We hope to get a nice experience 🚀✨..")
        print("You're grate 🦾🤩, your goal of steeps today is: \(goalsteeps)")
    } else {
        print("Sorry, your age less than 18")
    }
}}
class KSAUStudentHousing: KSAU{

}

// الملعب الرياضي
class KSAUStadium: KSAU{

}
class KSAUStage: KSAU{

}



let pnuuniversity = PNU(name: "Renad", universityName: "PNU")
let pnucollege = PNUCollege(pnucollege: "CCIS", pnumajor: "IT", pnugpa: 4.55)

let pnulib1 = PNULibrary()
let pnulib2 = PNULibrary(fullname: "Renad Majed", id: 10125, age: 24, gender: true)

let pnupasion = PNUHospital(passionname: "Ahmed Salem", id: 12049)

let pnugym = PNUGym(braceletnum: 36, gymequipment: true, age: 20, goalsteeps: 15000)

let psupasion = PSUHospital(passionname: "Amal", id: 13980)

let pnuhousing = PNUStudentHousing(firstname: "Lara", lastname: "Mohammed")


//print(University.name)
pnuuniversity.uni()
pnucollege.descriptioncoll()

pnulib1.brief()
pnulib2.condition()

pnupasion.bill1(x: 50, scout: 120)

pnugym.gyme(x: 20, y: 10000)

psupasion.bill2(x: 65, scout: 150)

pnuhousing.housing()
